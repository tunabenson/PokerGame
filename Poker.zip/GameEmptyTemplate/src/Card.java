public class Card {
    private String suit;
    private int cardVal;

    public Card(String suit, int cardVal) {
        this.suit = suit;
        this.cardVal = cardVal;
    }

    public int getCardVal() {
        return cardVal;
    }

    public String getSuit() {
        return suit;
    }
}
