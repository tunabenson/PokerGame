import java.util.ArrayList;

public class Deck {

    private Card[] cardList = new Card[52];

    public Deck(int numDecks) {
        String suit;
        for (int i = 0; i < numDecks; i++) {
            for (int counter = 1; counter <= 4; counter++) {
                for (int k = 1; k <= 13 ; k++) {
                    if (counter == 1) {
                        suit = "Hearts";
                    } else if (counter == 2) {
                        suit = "Clubs";
                    } else if (counter == 3) {
                        suit = "Spades";
                    } else {
                        suit = "Diamonds";
                    }
                    (k, suit)

                }

            }

        }
    }
}
